
-- Additional Upgrade Pack
CREATE TABLE IF NOT EXISTS saved_posts (
 id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
 user_id UUID NOT NULL,
 post_id UUID NOT NULL,
 created_at TIMESTAMP DEFAULT now(),
 UNIQUE(user_id, post_id)
);

ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS reputation_score INT DEFAULT 0;

CREATE OR REPLACE FUNCTION add_reputation(uid UUID, points INT)
RETURNS VOID
LANGUAGE plpgsql
AS $$
BEGIN
 UPDATE profiles
 SET reputation_score = COALESCE(reputation_score,0)+points
 WHERE id = uid;
END;
$$;
