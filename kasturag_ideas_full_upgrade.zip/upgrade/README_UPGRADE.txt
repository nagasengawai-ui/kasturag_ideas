
PUT IDEA FULL UPGRADE PACKAGE

Included:
- Saved Posts SQL
- Reputation System SQL
- Upgrade guidance for Trending Feed, Search, Dashboard, Comment Menu

This ZIP preserves the original project and adds upgrade files:
  upgrade/upgrade.sql
  upgrade/README_UPGRADE.txt
